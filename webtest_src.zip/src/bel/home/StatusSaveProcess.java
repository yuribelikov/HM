package bel.home;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;

public class StatusSaveProcess extends Thread
{
  private String data = null;
  boolean isAlive = true;


  public StatusSaveProcess()
  {
    start();
  }

  void setData(List<String> lines)
  {
    StringBuilder sb = new StringBuilder();
    for (String line : lines)
      sb.append(line).append("<br>");

    data = sb.toString();
  }

  public void run()
  {
    HM.log("SSP started");
    while (isAlive)
    {
      try
      {
        if (data == null)
        {
          sleep(1000);
          continue;
        }

        String encodedData = URLEncoder.encode(data.replaceAll("\n", "<br>"), "UTF-8");
        String type = "application/x-www-form-urlencoded";
        String statusSaveUrl = HM.properties.getProperty("status.save.url");
        HM.log("SSP, sending status data to: " + statusSaveUrl);
        URL u = new URL(statusSaveUrl);
        HttpURLConnection conn = (HttpURLConnection) u.openConnection();
        conn.setConnectTimeout(25000);
        conn.setDoOutput(true);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", type);
        conn.setRequestProperty("Content-Length", String.valueOf(encodedData.length()));
        OutputStream os = conn.getOutputStream();
        final byte[] bytes = encodedData.getBytes();
        HM.log("SSP, bytes to send: " + bytes.length);
        os.write(bytes);
        int responseCode = conn.getResponseCode();
        HM.log("SSP, server response: " + responseCode + ", " + conn.getResponseMessage());
        os.close();

        if (responseCode == 200)
          data = null;
        else
          sleepFor(20000);
      }
      catch (Exception e)
      {
        HM.log("SSP, error: " + e.getMessage());
        sleepFor(20000);
      }
    }
  }

  private void sleepFor(int period)
  {
    try
    {
      HM.log("SSP, sleep: " + period);
      sleep(period);
    }
    catch (Exception e)
    {
      HM.err(e);
    }
  }
}