package org.rm.tool.web.test;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

public class WebIPTestServlet extends HttpServlet
{
  static String lastStatus = "NA";
  static String data = "";
  static Properties sensors = new Properties();

  static
  {
    sensors.setProperty("inside.t", "Зал");
    sensors.setProperty("inside.h", "Зал (% вл.)");
    sensors.setProperty("outside.t", "Улица");
    sensors.setProperty("outside.h", "Улица (% вл.)");
    sensors.setProperty("test.t", "Малина");
    sensors.setProperty("warmOut.t", "Выход из печи");
    sensors.setProperty("warmIn.t", "Вход в печь");
    sensors.setProperty("warm.floor.t", "Пол в ванной");
    sensors.setProperty("faucet.t", "Кран на кухне");
    sensors.setProperty("room.t", "Кабинет");
    sensors.setProperty("bedroom.t", "Спальня");
    sensors.setProperty("cellar.t", "Погреб");
    sensors.setProperty("under.floor.t", "Подпол");
    sensors.setProperty("second.floor.t", "2-й этаж");
    sensors.setProperty("attic.t", "Чердак");
    sensors.setProperty("chimney.t", "Дым. труба");
  }


  public void init()
  {
    System.out.println("WebIPTest.init()");
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException
  {
    try
    {
      long t0 = System.currentTimeMillis();
      System.out.println("WebIPTest.doGet()");
      String table = "";
      if (data.length() > 0)
        table = parseData();

      response.setContentType("text/html");
      response.setCharacterEncoding("UTF-8");
      response.getWriter().write("<HTML lang=\"ru\">\n" +
        " <head>\n" +
        "  <meta charset=\"utf-8\">\n" +
        "  <meta name=\"viewport\" content=\"width=300, initial-scale=1\">\n" +
        "  <title>HM</title>\n" +
        "  <style>\n" +
        "   body {font-family:Trebuchet MS,Arial,Helvetica,sans-serif;font-size:0.9em;}\n" +
        "   table {border-collapse:collapse;font-size:0.9em;white-space:nowrap;}\n" +
        "   tr:nth-child(even) {background: #ffe;} " +
        "   td, th {border:1px solid #ccc;padding:4px 10px 4px 10px;color:#333;}\n" +
        "   td+td {text-align: right;}\n" +
        "   th+th {text-align: left;}\n" +
        "   th {background-color:#EEE}\n" +
        "   thead tr.a {font-size:85%;}\n" +
        "   p {font-size:85%;}\n" +
        "   .red {color:red;}\n" +
        "   div {float:left; margin-right:30px;}" +
        "  </style>\n" +
        " </head>\n" +
        "<body>" + table + "<br><br>" + lastStatus.replaceAll("\n", "<br>") + "</body></HTML>");

      System.out.println("WebIPTest.doGet() took(ms): " + (System.currentTimeMillis() - t0));
    }
    catch (Exception e)
    {
      throw new ServletException(e);
    }
  }

  private String parseData()
  {
    final char cs = ',';   // column separator
    final char rs = ';';   // row separator
    DecimalFormat f = new DecimalFormat("##.0");
    try
    {
      String[] rows = data.split("" + rs);
//      List<String> topRow = Arrays.asList(rows[0].split("" + cs));
      String[] statusRows = lastStatus.split("\n");   // processing status
      ArrayList<String> firstColumn = new ArrayList<>();
      for (int i = 2; i < statusRows.length; i++)
        if (!statusRows[i].startsWith("version"))
        {
          String key = statusRows[i].substring(0, statusRows[i].indexOf('=')).trim();
          firstColumn.add(sensors.getProperty(key));
        }
        else
          break;

      StringBuilder sb = new StringBuilder();
      sb.append("<table>");
      sb.append("\n<thead><tr>");
      sb.append("\n<th>").append("").append("</th>");
      sb.append("\n<th>").append("Изм.").append("</th>");
      String[] cols = rows[0].split("" + cs);
      for (String col : cols)
        sb.append("\n<th>").append(col).append("</th>");

      sb.append("\n</tr></thead>");

      sb.append("\n   <tbody>");
      for (int i = 0; i < firstColumn.size(); i++)
      {
        if (i >= rows.length)
          break;

        sb.append("\n    <tr>");
        sb.append("\n      <td>").append(firstColumn.get(i)).append("</td>");
        cols = rows[i + 1].split("" + cs);
        String change = "";
        double lastValue = parse(cols[0]);
        double prevValue = parse(cols[cols.length > 0 ? 1 : 0]);
        double diff = lastValue - prevValue;
        Double abs = Math.abs(diff);
        if (abs != 0 && !abs.isNaN())   // setting +++ ---
        {
          int n = 5;
          if (abs < 0.5)
            n = 1;
          else if (abs < 1.5)
            n = 2;
          else if (abs < 3.5)
            n = 3;
          else if (abs < 7.5)
            n = 4;

          for (int k = 0; k < n; k++)
            change += (diff > 0 ? "+" : "-");
        }
        sb.append("\n      <td>").append(change).append("</td>");

        for (String col : cols)
          sb.append("\n      <td").append(statusRows[i + 2].contains(".t =") ? bgColor(col) : "").append(">").append(f.format(parse(col))).append("</td>");

        sb.append("\n    </tr>");
      }

      sb.append("\n   </tbody>\n</table>");
      return sb.toString();
    }
    catch (Exception e)
    {
      e.printStackTrace();
      return e.getMessage();
    }
  }

  /*
  public void doGet0(HttpServletRequest request, HttpServletResponse response) throws ServletException
  {
    try
    {
      long t0 = System.currentTimeMillis();
      System.out.println("WebIPTest.doGet()");
      String body = lastStatus;
      if (firstColumn.size() > 0)
      {
        StringBuilder sb = new StringBuilder();
        sb.append("<table>");
        sb.append("\n<thead><tr>");
        sb.append("\n<th>").append("").append("</th>");
        sb.append("\n<th>").append("++ --").append("</th>");
        for (int j = 0; j < topRow.size(); j++)
          if (valuable(j))
            sb.append("\n<th>").append(topRow.get(j)).append("</th>");

        sb.append("\n</tr></thead>");
        sb.append("\n   <tbody>");
        for (int i = 0; i < firstColumn.size(); i++)
        {
          sb.append("\n    <tr>");
          sb.append("\n      <td>").append(firstColumn.get(i)).append("</td>");
          String change = "";
          double lastValue = parse(data.get(0).get(i));
          double valueAt10idx = parse((data.size() > 9 ? data.get(9).get(i) : data.get(data.size() - 1).get(i)));
          double diff = lastValue - valueAt10idx;
          Double abs = Math.abs(diff);
          if (abs != 0 && !abs.isNaN())   // setting +++ ---
          {
            int n = 5;
            if (abs < 0.5)
              n = 1;
            else if (abs < 1.5)
              n = 2;
            else if (abs < 3.5)
              n = 3;
            else if (abs < 7.5)
              n = 4;

            for (int k = 0; k < n; k++)
              change += (diff > 0 ? "+" : "-");
          }

          sb.append("\n      <td>").append(change).append("</td>");
          for (int j = 0; j < data.size(); j++)
            if (valuable(j))
              sb.append("\n      <td").append(firstColumn.get(i).endsWith(".t") ? bgColor(data.get(j).get(i)) : "").append(">").append(data.get(j).get(i)).append("</td>");

          sb.append("\n    </tr>");
        }

        sb.append("\n   </tbody>\n</table>");
        body = sb.toString() + "<br>" + body;
      }

      response.getWriter().write("<HTML>" +
        " <head>\n" +
        "  <title>HM</title>\n" +
        "  <meta name=\"viewport\" content=\"width=300, initial-scale=1\">\n" +
        "  <style>\n" +
        "   body {font-family:Trebuchet MS,Arial,Helvetica,sans-serif;font-size:0.9em;}\n" +
        "   table {border-collapse:collapse;font-size:0.9em;white-space:nowrap;}\n" +
        "   tr:nth-child(even) {background: #ffe;} " +
        "   td, th {border:1px solid #ccc;padding:4px 10px 4px 10px;color:#333;}\n" +
        "   td+td {text-align: right;}\n" +
        "   th+th {text-align: left;}\n" +
        "   th {background-color:#EEE}\n" +
        "   thead tr.a {font-size:85%;}\n" +
        "   p {font-size:85%;}\n" +
        "   .red {color:red;}\n" +
        "   div {float:left; margin-right:30px;}" +
        "  </style>\n" +
        " </head>\n" +
        "<body>" + body + "</body></HTML>");

      System.out.println("WebIPTest.doGet() took(ms): " + (System.currentTimeMillis() - t0));
    }
    catch (Exception e)
    {
      throw new ServletException(e);
    }
  }
*/
  private boolean valuable(int j)
  {
    return (j == 0 || j == 1 || j == 2 || j == 3 || j == 5 || j == 10 || j == 30 || j % 60 == 0);
  }

  private double parse(String s)
  {
    try
    {
      return Double.parseDouble(s);
    }
    catch (NumberFormatException e)
    {
      return Double.NaN;
    }
  }

  private String bgColor(String s)
  {
    try
    {
      String bgColor = ""; // " bgcolor=\"#00FF00\"";
      Double d = parse(s);
      if (d.equals(Double.NaN))
        bgColor = "CCCCCC";
      else
      {
        int t = (int) Math.round(d);
        if (t >= 80)
          bgColor = "FF0000";
        else if (t >= 60)
          bgColor = "FF6600";
        else if (t >= 40)
          bgColor = "FFBB00";
        else if (t >= 30)
          bgColor = "FFFF00";
        else if (t <= 0)
          bgColor = "6666FF";
        else if (t <= 5)
          bgColor = "9999FF";
        else if (t <= 10)
          bgColor = "CCCCFF";
      }

      return bgColor.length() > 0 ? " bgcolor=\"#" + bgColor + "\"" : "";
    }
    catch (NumberFormatException e)
    {
      return "";
    }
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException
  {
    try
    {
      long t0 = System.currentTimeMillis();
      final int contentLength = request.getContentLength();
      System.out.println("WebIPTest.doPost(), len: " + contentLength + ", " + new Date());
      char[] ca = new char[contentLength];
      final int read = request.getReader().read(ca);
      System.out.println("WebIPTest.doPost(), read: " + read);
      String postedData = URLDecoder.decode(new String(ca), "UTF-8");
      System.out.println("WebIPTest.doPost(), postedData.size: " + postedData.length());
      System.out.println("WebIPTest.doPost(), took(ms): " + (System.currentTimeMillis() - t0));

      if (postedData.startsWith("data:"))
        data = postedData.substring(5);
      else
        lastStatus = postedData;

    }
    catch (Exception e)
    {
      throw new ServletException(e);
    }
  }

/*
  private void parseStatus(String status)
  {
    try
    {
      int MAX = 24 * 60 + 10;
      DecimalFormat f = new DecimalFormat("##.0");
      status = status.replace("<br>", "\n");
      String[] rows = status.split("\n");
      String[] sa = rows[0].split(" ");
      topRow.add(0, sa[2] + "<br>" + sa[3].substring(0, sa[3].indexOf(',')) + "<br>" + rows[1]);
      if (topRow.size() > MAX)
        topRow.remove(data.size() - 1);
      firstColumn.clear();
      ArrayList<String> dataCol = new ArrayList<>();
      for (int i = 2; i < rows.length; i++)   // processing data
      {
        if (rows[i].startsWith("version"))
          break;

        sa = rows[i].split("=");
        firstColumn.add(sa[0].trim());
        try
        {
          dataCol.add(f.format(Double.parseDouble(sa[1].trim())));
        }
        catch (NumberFormatException e)
        {
          dataCol.add("NaN");
        }
      }

      data.add(0, dataCol);
      if (data.size() > MAX)
        data.remove(data.size() - 1);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
*/
}
