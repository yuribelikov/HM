package org.rm.tool.web.test;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class WebMonTest
{
  public final static Logger lgr = Logger.getLogger(WebMonTest.class);


  public static void main0(String[] args)
  {
    PropertyConfigurator.configure("log4j.properties");
    try
    {
      JMXServiceURL url = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://cache01.prod:9003/jmxrmi");
      JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
      MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();

      echo("\nDomains:");
      String domains[] = mbsc.getDomains();
      Arrays.sort(domains);
      for (String domain : domains)
        echo("\tDomain = " + domain);

      echo("\nMBeanServer default domain = " + mbsc.getDefaultDomain());
      echo("\nMBean count = " + mbsc.getMBeanCount());
      echo("\nQuery MBeanServer MBeans:");
      Set<ObjectName> names = new TreeSet<>(mbsc.queryNames(null, null));
      int broadcastConns = 0;
      int rtmpConns = 0;
      for (ObjectName name : names)
      {
        echo("\tObjectName = " + name);
        if (name.toString().startsWith("org.red5.server:type=ClientBroadcastStream,"))
          broadcastConns++;
        else if (name.toString().startsWith("org.red5.server:type=RTMPMinaConnection,"))
          rtmpConns++;
      }

//      echo("memory: " + mbsc.getMBeanInfo(new ObjectName("java.lang:type=Memory")));
      javax.management.openmbean.CompositeDataSupport heapMemoryUsage = (javax.management.openmbean.CompositeDataSupport) mbsc.getAttribute(new ObjectName("java.lang:type=Memory"), "HeapMemoryUsage");
//      echo("heap: " + heapMemoryUsage);
//      echo("heap.class: " + heapMemoryUsage.getClass().getName());
      echo("max GB: " + (long) ((long) heapMemoryUsage.get("max") / (10.24 * 1024 * 1024)) / 100.0);
      echo("used GB: " + (long) ((long) heapMemoryUsage.get("used") / (10.24 * 1024 * 1024)) / 100.0);

      echo("broadcastConns: " + broadcastConns);
      echo("rtmpConns: " + rtmpConns);

//      MBeanInfo mBeanInfo = mbsc.getMBeanInfo(new ObjectName("java.lang:type=Threading"));
//      echo("Threading: " + mBeanInfo);
      echo("ThreadCount: " + mbsc.getAttribute(new ObjectName("java.lang:type=Threading"), "ThreadCount"));
//      Object allThreadIds = mbsc.getAttribute(new ObjectName("java.lang:type=Threading"), "AllThreadIds");
//      echo("allThreadIds: " + allThreadIds);
//      echo("allThreadIds.class: " + allThreadIds.getClass().getName());
//
//      mBeanInfo = mbsc.getMBeanInfo(new ObjectName("org.red5.server:name=org.springframework.jmx.support.ConnectorServerFactoryBean#0,type=RMIConnectorServer"));
//      echo("RMIConnectorServer: " + mBeanInfo);
//
//      String[] ConnectionIds = (String[])mbsc.getAttribute(new ObjectName("org.red5.server:name=org.springframework.jmx.support.ConnectorServerFactoryBean#0,type=RMIConnectorServer"), "ConnectionIds");
//      echo("ConnectionIds.length: " + ConnectionIds.length);


//      echo("server: " + mbsc.getMBeanInfo(new ObjectName("Catalina:type=Server")));
      echo("threadPool: " + mbsc.getMBeanInfo(new ObjectName("Catalina:type=ThreadPool,name=\"http-0.0.0.0-5080\"")));
      echo("currentThreadsBusy: " + mbsc.getAttribute(new ObjectName("Catalina:type=ThreadPool,name=\"http-0.0.0.0-5080\""), "currentThreadsBusy"));

//      echo("dbPool: " + mbsc.getMBeanInfo(new ObjectName("tomcat.jdbc:name=\"jdbc/OracleDS\",context=/genie2-web,engine=Catalina,type=ConnectionPool,host=localhost,class=org.apache.tomcat.jdbc.pool.DataSource")));

//      echo("db ds: " + mbsc.getMBeanInfo(new ObjectName("Catalina:type=DataSource,context=/genie2-web,host=localhost,class=javax.sql.DataSource,name=\"jdbc/OracleDS\"")));

//      echo("numActive: " + mbsc.getAttribute(new ObjectName("Catalina:type=DataSource,context=/genie2-web,host=localhost,class=javax.sql.DataSource,name=\"jdbc/OracleDS\""), "numActive"));

    }
    catch (Exception e)
    {
      lgr.warn(e.getMessage(), e);
    }
  }

  public static void main(String[] args)
  {
    PropertyConfigurator.configure("log4j.properties");
    try
    {
      JMXServiceURL url = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://cache01.prod:9003/jmxrmi");
      JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
      MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();

      Set<ObjectName> names = new TreeSet<>(mbsc.queryNames(null, null));
      int broadcastConns = 0;
      int rtmpConns = 0;
      int httpConns = 0;
      for (ObjectName name : names)
      {
        echo("\tObjectName = " + name);
        if (name.toString().startsWith("org.red5.server:type=ClientBroadcastStream,"))
        {
//          echo("\tObjectName = " + name);
          broadcastConns++;
        }
        else if (name.toString().startsWith("org.red5.server:type=RTMPMinaConnection,"))
        {
//          echo("\tObjectName = " + name);
          rtmpConns++;
        }
        else if (name.toString().startsWith("red5Engine:type=RequestProcessor,worker=http-0.0.0.0-5080,"))
        {
//          echo("\tObjectName = " + name);
          httpConns++;
        }
      }

      javax.management.openmbean.CompositeDataSupport heapMemoryUsage = (javax.management.openmbean.CompositeDataSupport) mbsc.getAttribute(new ObjectName("java.lang:type=Memory"), "HeapMemoryUsage");
      echo("max GB: " + (long) ((long) heapMemoryUsage.get("max") / (10.24 * 1024 * 1024)) / 100.0);
      echo("used GB: " + (long) ((long) heapMemoryUsage.get("used") / (10.24 * 1024 * 1024)) / 100.0);

      echo("broadcastConns: " + broadcastConns);
      echo("rtmpConns: " + rtmpConns);
      echo("httpConns: " + httpConns);

      echo("ThreadCount: " + mbsc.getAttribute(new ObjectName("java.lang:type=Threading"), "ThreadCount"));

//      echo("threadPool: " + mbsc.getMBeanInfo(new ObjectName("red5Engine:type=ThreadPool,name=http-0.0.0.0-5080")));
      echo("maxThreads: " + mbsc.getAttribute(new ObjectName("red5Engine:type=ThreadPool,name=\"http-nio-0.0.0.0-5080\""), "maxThreads"));
      echo("currentThreadsBusy: " + mbsc.getAttribute(new ObjectName("red5Engine:type=ThreadPool,name=\"http-nio-0.0.0.0-5080\""), "currentThreadsBusy"));
    }
    catch (Exception e)
    {
      lgr.warn(e.getMessage(), e);
    }
  }

  static void echo(Object o)
  {
    lgr.info(o);
  }
}
