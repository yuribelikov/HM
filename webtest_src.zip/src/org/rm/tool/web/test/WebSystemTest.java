package org.rm.tool.web.test;

import flex.messaging.io.amf.client.AMFConnection;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class WebSystemTest
{
  public final static Logger lgr = Logger.getLogger(WebSystemTest.class);

  static String server = "localhost:8080"; // "mw04.prod.rmcity.net:8080";


  public static void main(String[] args)
  {
    PropertyConfigurator.configure("log4j.properties");
    try
    {
      lgr.info("started..");

      lgr.info("ObjectiveCache.size: " + viewCache("ObjectiveCache", "size", 0));
      lgr.info("ObjectiveCache.keys: " + viewCache("ObjectiveCache", "keys", 0));
      lgr.info("ObjectiveCache.get: " + viewCache("ObjectiveCache", "get", 22));
      lgr.info("XLessonCache.size: " + viewCache("XLessonCache", "size", 0));
      lgr.info("XItemCache.size: " + viewCache("XItemCache", "size", 0));
      lgr.info("XLessonCache.get: " + viewCache("XLessonCache", "get", 513));
      lgr.info("XItemCache.view: " + viewCache("XItemCache", "view", "6-001-150"));
      lgr.info("UserCache.keys: " + viewCache("UserCache", "keys", null));
      lgr.info("UserCache.get: " + viewCache("UserCache", "get", 40125749));
      lgr.info("SchoolClassCache.keys: " + viewCache("SchoolClassCache", "keys", null));
      Object result = viewCache("SchoolClassCache", "get", 29191);
      lgr.info("result: " + result);

      lgr.info("done.");
    }
    catch (Exception e)
    {
      lgr.warn(e.getMessage(), e);
    }
  }

  private static Object viewCache(String cacheName, String what, Object key) throws Exception
  {
    AMFConnection amfConn = new AMFConnection();
    try
    {
      amfConn.connect("http://" + server + "/genie2-web/messagebroker/amf");
      return amfConn.call("SystemServiceDestination.viewCache", cacheName, what, key);
    }
    finally
    {
      amfConn.close();
    }
  }
}
