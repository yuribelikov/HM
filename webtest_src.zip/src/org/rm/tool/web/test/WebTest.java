package org.rm.tool.web.test;

import flex.messaging.io.amf.client.AMFConnection;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Properties;

public class WebTest
{
  public final static Logger lgr = Logger.getLogger(WebTest.class);

  static String server = "localhost";
  static int threads = 100;
  static int calls = 100;
  static int startSleep = 100;
  static int callSleep = 100;

  static int activeThreads = 0;


  public static void main(String[] args)
  {
    PropertyConfigurator.configure("log4j.properties");

    try
    {
      lgr.info("started..");
      Properties props = new Properties();
      props.load(new FileReader("webtest.properties"));
      if (props.containsKey("server"))
        server = props.getProperty("server");

      if (props.containsKey("threads"))
        threads = Integer.parseInt(props.getProperty("threads"));

      if (props.containsKey("calls"))
        calls = Integer.parseInt(props.getProperty("calls"));

      if (props.containsKey("start.sleep"))
        startSleep = Integer.parseInt(props.getProperty("start.sleep"));

      if (props.containsKey("call.sleep"))
        callSleep = Integer.parseInt(props.getProperty("call.sleep"));


      long t0 = now();
      while (threads-- > 0)
        newAMFThread();

      while (activeThreads > 0)
      {
        lgr.info("active threads: " + activeThreads);
        Thread.sleep(1000);
      }
      lgr.info("finished, time: " + (now() - t0));

      Thread.sleep(1000);
      lgr.info("active threads: " + activeThreads);

      AMFConnection amfConn = new AMFConnection();
      amfConn.connect("http://" + server + ":8080/webtest/messagebroker/amf");
      lgr.info(amfConn.call("TestDestination.get"));
      amfConn.close();

    }
    catch (Exception e)
    {
      lgr.warn(e.getMessage(), e);
    }
  }

  private static void newThread()
  {
    try
    {
      Thread.sleep(0, (int) (1000 * Math.random()));
    }
    catch (Exception e)
    {
      lgr.warn(e.getMessage(), e);
    }

    new Thread()
    {
      public void run()
      {
        WebTest.activeThreads++;
        try
        {
          lgr.info("thread started: " + getName());
          int call = 0;
          while (call++ < WebTest.calls)
          {
            URL url = new URL("http://" + server + ":8080/webtest?thread=" + getName() + "&call=" + call);
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            String result = in.readLine();
//            lgr.info("result: " + result);
            in.close();
//            Thread.sleep(0, (int) (1000 * Math.random()));
          }
          lgr.info("thread finished: " + getName());
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
        WebTest.activeThreads--;
      }
    }.start();
  }

  private static void newAMFThread()
  {
    try
    {
//      Thread.sleep(0, (int) (1000 * Math.random()));
      Thread.sleep(startSleep);
    }
    catch (Exception e)
    {
      lgr.warn(e.getMessage(), e);
    }

    new Thread()
    {
      public void run()
      {
        WebTest.activeThreads++;
        try
        {
          lgr.info("AMF thread started: " + getName());
          AMFConnection amfConn = new AMFConnection();
          amfConn.connect("http://" + server + ":8080/webtest/messagebroker/amf");
          int call = 0;
          while (call++ < WebTest.calls)
          {
//            amfConn.call("ExternalDestination.aaa");
            amfConn.call("TestDestination.increment");
//            lgr.info("result: " + result);
//            Thread.sleep(0, (int) (1000 * Math.random()));
//            Thread.sleep(callSleep);
          }
          amfConn.close();
          lgr.info("AMF thread finished: " + getName());
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
        WebTest.activeThreads--;
      }
    }.start();
  }

  public static long now()
  {
    return System.currentTimeMillis();
  }

  public static long nowNano()
  {
    return 1000000 * now() + System.nanoTime() % 1000000;
  }

  public void test()
  {

  }
}
