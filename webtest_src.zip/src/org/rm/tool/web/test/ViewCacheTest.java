package org.rm.tool.web.test;

import flex.messaging.io.amf.client.AMFConnection;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;

public class ViewCacheTest
{
  public final static Logger lgr = Logger.getLogger(ViewCacheTest.class);
  /**
   * can be obtained by the following query (for instance):
   *
     select groupconcat(sc.classid || 'l') as classes
       ,groupconcat(distinct s.schoolid || 'l') as schools
       ,max(d.districtid) as districtid
     from t_school s
      join t_schoolclass sc on s.schoolid = sc.schoolid
      join t_district d on s.districtid = d.districtid
     where d.name = 'SmarterSolvingTestDistrict'
   */

  static ArrayList<Long> classes = new ArrayList<>(Arrays.asList(new Long[]{71462l,71465l,71461l,71467l,71459l,71463l,71466l,71468l,71460l,71464l,62126l}));
  static ArrayList<Long> schools = new ArrayList<>(Arrays.asList(new Long[]{7997l,8337l}));
  static ArrayList<Long> districts = new ArrayList<>(Arrays.asList(new Long[]{3849l}));
//  static String server = "localhost:8080";
//  static String server = "mt1jb03.rmcity.net:8080";
//  static String server = "ht2jb03.rmcity.net:8080";
  static String server = "mw03.prod.rmcity.net:8080";


  public static void main(String[] args)
  {
    //PropertyConfigurator.configure("log4j.properties");
    try
    {
      clearCache("mw01.prod.rmcity.net:8080");
      clearCache("mw02.prod.rmcity.net:8080");
      clearCache("mw03.prod.rmcity.net:8080");
      clearCache("mw04.prod.rmcity.net:8080");
      clearCache("mw05.prod.rmcity.net:8080");

//      lgr.info("connecting to server: " + server);
//      lgr.info("ObjectiveCache.size: " + viewCache("ObjectiveCache", "size", 0));
//      lgr.info("ObjectiveCache.keys: " + viewCache("ObjectiveCache", "keys", 0));
//      Object o = viewCache("ObjectiveCache", "get", 29);
//      lgr.info("ObjectiveCache.get: " + o);
//      lgr.info("XLessonCache.size: " + viewCache("XLessonCache", "size", 0));
//      lgr.info("XItemCache.size: " + viewCache("XItemCache", "size", 0));
//      lgr.info("XLessonCache.get: " + viewCache("XLessonCache", "get", 513));
//      lgr.info("XItemCache.view: " + viewCache("XItemCache", "view", "6-001-150"));
////      lgr.info("UserCache.keys: " + viewCache("UserCache", "keys", null));
//      lgr.info("UserCache.get: " + viewCache("UserCache", "get", 40125749));
////      lgr.info("SchoolClassCache.keys: " + viewCache("SchoolClassCache", "keys", null));
//      Object result = viewCache("SchoolClassCache", "get", 29191);
//      lgr.info("result: " + result);

    }
    catch (Exception e)
    {
      lgr.warn(e.getMessage(), e);
    }
  }

  private static Object viewCache(String cacheName, String what, Object key) throws Exception
  {
    AMFConnection amfConn = new AMFConnection();
    try
    {
      amfConn.connect("http://" + server + "/genie2-web/messagebroker/amf");
      return amfConn.call("SystemServiceDestination.viewCache", cacheName, what, key);
    }
    finally
    {
      amfConn.close();
    }
  }


  private static void clearCache(String server) throws Exception
  {
    AMFConnection amfConn = new AMFConnection();
    try
    {
      amfConn.connect("http://" + server + "/genie2-web/messagebroker/amf");
      amfConn.call("SystemServiceDestination.clearSchoolCache", districts, schools, classes);
      System.out.println("done for " + server);
    }
    finally
    {
      amfConn.close();
    }
  }
}
