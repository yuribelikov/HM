package org.rm.tool.web.test;


import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class TestServiceAMF
{
  public final static Logger lgr = Logger.getLogger(TestServiceAMF.class);

  volatile long t0 = 0;
  volatile int c0 = 0;
  volatile int cps = 0;
  volatile int maxCps = 0;
  volatile int count0 = 0;

  volatile int c = 0;
  AtomicInteger count = new AtomicInteger(0);
  static final ArrayList<String> list = new ArrayList<String>(100000);
  static final Map<String, Integer> map = Collections.synchronizedMap(new HashMap<String, Integer>(100000));
  static final Map<Integer, String> map2 = Collections.synchronizedMap(new HashMap<Integer, String>(100000));


  public TestServiceAMF()
  {
    lgr.info("new TestServiceAMF");
  }

  public void increment()
  {
    c++;
    count.incrementAndGet();
    synchronized (list)
    {
      list.add(Thread.currentThread().getName());
    }

    synchronized (map)
    {
      Integer i = map.get(Thread.currentThread().getName());
      int newI = (i != null ? i + 1 : 1);
      map.put(Thread.currentThread().getName(), newI);
    }

//    synchronized (map2)
//    {
//      int key = (int) (1000 * Math.random());
//      String str = map2.get(key);
//      String newString = (str != null ? str + str : "" + System.currentTimeMillis());
//      if (newString.length() < 10000)
//        map2.put(key, newString);
//      else
//      {
//        map2.remove(key);
//        lgr.info("removed: " + key);
//      }
//    }

//    count0++;
//    long t = System.currentTimeMillis();
//    if (t0 == 0)
//      t0 = t;
//    else if (t - t0 > 999)
//    {
////      cps = count.get() - c0;
//      cps = count0 - c0;
////      c0 = count.get();
//      c0 = count0;
//      t0 = t;

//      if (cps > maxCps)
//        maxCps = cps;

//      lgr.info("increment: " + count + ", cps: " + cps + " (max: " + maxCps + ")");
//    }

  }

  public String get()
  {
    int mapTotal = 0;
    for (Integer i : map.values())
      mapTotal += i;

    String result = "get, c: " + c + ", count: " + count + ", list.size(): " + list.size() +
      ", mapTotal: " + mapTotal + ", map.size(): " + map.size() + ", map2.size(): " + map2.size();
    lgr.info(result);

    return result;
  }
}
