package org.rm.tool.web.test;

import org.apache.log4j.Logger;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public class WebTestServlet extends HttpServlet
{
  public final static Logger lgr = Logger.getLogger(WebTestServlet.class);
  DataSource ds;
  long time = System.currentTimeMillis();

  //  volatile long count = 0;
  AtomicInteger count = new AtomicInteger(0);
  ArrayList<String> list = new ArrayList<>(100000);


  public WebTestServlet()
  {
    lgr.info("new WebTestServlet: " + time);
  }

  public void init()
  {
    try
    {
      lgr.info("WebTestServlet.init(), time: " + time);
      Context initContext = new InitialContext();
      Context envContext = (Context) initContext.lookup("java:/comp/env");
      ds = (DataSource) envContext.lookup("jdbc/OracleDS");
      lgr.info("WebTestServlet.init(), ds: " + ds);

    }
    catch (Exception e)
    {
      lgr.warn(e.getMessage(), e);
    }
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException
  {
    try
    {
      String thread = request.getParameter("thread");
      if (thread != null)
      {
        String call = request.getParameter("call");
        String result = thread + " --> " + call;
        log("WebTestServlet.doGet(), thread --> call: " + result);

//        count.incrementAndGet();
//        list.add(result);
//        log(Thread.currentThread().getName() + ", count: " + count);

        response.getWriter().write(result);
        return;
      }

      String db = request.getParameter("db");
      if (db != null)
      {
        Connection conn = ds.getConnection();
        lgr.info("WebTestServlet.doGet(), db, conn: " + conn);
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery("select * from t_systemproperties order by key");
        String result = "";
        while (rs.next())
          result += rs.getString(1) + " = " + rs.getString(2) + "<br>";

        st.close();
        rs.close();
        conn.close();

        lgr.info("WebTestServlet.doGet(), db, result: " + result);
        response.getWriter().write(result);
        return;
      }

      String get = request.getParameter("get");
      if (get != null)
      {
        String result = "WebTestServlet.doGet(), get, count: " + count + ", list.size(): " + list.size();
        lgr.info(result);
        response.getWriter().write(result);
      }

    }
    catch (Exception e)
    {
      throw new ServletException(e);
    }
  }

}
